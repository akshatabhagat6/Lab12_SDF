import sauce
class Pumpkin_Sauce(sauce.Sauce):

    def __init__(self, cost) -> None:
        super().__init__(cost)