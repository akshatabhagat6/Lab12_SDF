import sauce
class Barbecue_Sauce(sauce.Sauce):

    def __init__(self, cost) -> None:
        super().__init__(cost)
