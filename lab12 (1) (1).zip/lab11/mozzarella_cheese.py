import cheese

class Mozzarella_Cheese(cheese.Cheese):

    def __init__(self, cost) -> None:
        super().__init__(cost)