# this is a class named car
class car:
	def parts():
		pass

c = car()

# prints the class of the object c
print(c.__class__)

# this prints the name of the class
classes = c.__class__
# prints the name of the class
print(classes.__name__)
