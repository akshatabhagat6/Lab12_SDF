import dough

class Thick_Crust_Dough(dough.Dough):

    def __init__(self, cost) -> None:
        super().__init__(cost)