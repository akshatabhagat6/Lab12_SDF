import cheese

class Provolone_Cheese(cheese.Cheese):

    def __init__(self, cost) -> None:
        super().__init__(cost)