class Dough:

    def __init__(self, cost) -> None:
        self.__cost = cost

    def get_cost(self):
        return self.__cost
        